<?php
if(isset($_POST['submit']))
{
	//$company="info@spaksit.com";
	$name=$_POST['enq_name'];
	$mail=$_POST['enq_email'];
	$ph=$_POST['enq_mob'];
	$place=$_POST['enq_place'];
	$message=$_POST['enq_msg'];
	$subject="Enquiry Kuro Obi / ".$name;
	
	$pageaddress=$_SERVER['HTTP_REFERER'];
	//$mailheader = "From: ".$_POST["enq_email"]."\r\n";
    $headers .= "MIME-Version: 1.0\r\n";
	$headers .= "Content-type: text/html; charset=iso-8859-1\r\n";
	$headers .= 'From: KURO_OBI<webmaster@kuroobishotokan.com>' . "\r\n";
	// $headers .= "From:".$name."<".$company.">\n";
     $headers .= "Enquiry via WEB SITE(Kuro Obi Karate) from :: ".$name." ::";

	$mailbody= '<table width="70%" border="0" align="center" cellpadding="5" cellspacing="2">';
	$mailbody.='<tr><td colspan="2"><strong><font size="+1">Enquiry</font></strong></td></tr>';
	$mailbody.='<tr><td width="30%" height="20">Name : </td><td width="70%">'.$name.'</td></tr>';

	$mailbody.='<tr><td height="20">E-mail : </td><td>'.$mail.'</td></tr>';
	
	$mailbody.='<tr><td height="20">Phone : </td><td>'.$ph.'</td></tr>';
	$mailbody.='<tr><td height="20">Place : </td><td>'.$place.'</td></tr>';
	//$mailbody.='<tr><td height="20">Address : </td><td>'.$address.'</td></tr>';

	
	$mailbody.='<tr><td valign="top" height="20">Message : </td><td valign="top">'.$message.'</td></tr></table>';
	//$to="spaksit@gmail.com";
    $to="shotokantomy@gmail.com";
	
	$a=@mail($to,$subject,$mailbody,$headers);



	if($a)
	{
	echo '<script type="text/javascript">alert("Your enquiry has been send successfully");window.location.href="'.$pageaddress.'";</script>';
	}
	else
	{
	echo '<script type="text/javascript">alert("You cannot send enquiry at this time");window.location.href="'.$pageaddress.'?enq";</script>';
	}
} 
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Kuro Obi Shotokan | contact us</title>
<link href="css/basic.css" type="text/css" rel="stylesheet" />



<script src="js/jquery-1.9.1.min.js" type="text/javascript"></script>
    <script type="text/javascript" src="js/jquery.nivo.slider.js"></script>
    <link href="css/slider.css" rel="stylesheet" type="text/css" media="all" />
    <script type="text/javascript">
    $(window).load(function() {
        $('#slider').nivoSlider();
    });
    </script>
    <script type="text/javascript" language="javascript" src="js/jquery.carouFredSel-6.2.1-packed.js"></script>
    <script type="text/javascript" language="javascript">
    $(document).ready(function() {
        $('#foo5').carouFredSel({
            responsive: true,
            width: '100%',
            height: 80,
            scroll: 1,
            items: {
                //width     : 200,
                height: 80,
                visible: {
                    min: 2,
                    max: 4
                }
            }
        }).trigger('resize');
    });
    $(document).ready(function() {
        $('#foo6').carouFredSel({
            responsive: true,
            width: '100%',
            height: 287,
            scroll: 1,
            items: {
                //width     : 200,
                height: 80,
                visible: {
                    min: 2,
                    max: 4
                }
            }
        }).trigger('resize');
    });
     </script>
</head>

<body>
<?php include_once('includes/header.php');?>





<div class="wrapa">
<br>
<div class="ipcH1C"><h1 style="width:135px;"> CONTACT US </h1></div>

<div class="flL" style="width:470px;"><br>


<form class="quickform" action="contact.php" name="cf" method="post">
    	<input type="text" name="enq_name" placeholder="Name" ><input type="email" name="enq_email" placeholder="E-mail " >
<input type="text" name="enq_mob" placeholder="Mobile" ><input type="text" name="enq_place" placeholder="Place" >
<textarea name="enq_msg" placeholder="Comments..." ></textarea>
<div class="clr"></div>
<input type="submit" value="SUBMIT" name="submit" >
    </form>


</div> <!--end flL-->

<div class="flL" style="margin:80px 0px 0px 75px;color:#363333;">
<img src="images/mapicon.jpg" /><b>OUR ADDRESS</b><br>
KURO OBI ACADEMY OF SHOTOKAN KARATE<br>
Elayidath Building, Phoenix School Jn,<br>P.O Methala, Kodungallur, Thrissur - 680669<br>
Ph: +91 9946666615, 9895017014

</div><br>
<div class="clr"></div>
<iframe src="https://www.google.com/maps/embed?pb=!1m16!1m12!1m3!1d7853.500618205187!2d76.17417806181298!3d10.200921054123553!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!2m1!1sP.O+Methala%2C+Kodungallur%2C!5e0!3m2!1sen!2sin!4v1448260631365"  width="1000" height="300" frameborder="0" style=" display:block;order:0; width:1000px; margin:auto;"></iframe> 


</div> <!--./wrapa-->
<div class="clr"></div>

<?php include_once('includes/footer.php'); ?>


</body>
</html>
<?php require_once("K8ur5obi/system/config.php"); ?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Kuro Obi Shotokan</title>
<link href="css/basic.css" type="text/css" rel="stylesheet" />

<meta name="google-site-verification" content="ot_KU_NtOSEQvHhNJJH5rAo87AESW82vsCTOr1JM-6A" />

<!-- initialise jessor scroller-->
<script type="text/javascript" src="jessorscroller/jquery-1.9.1.min.js"></script>
<script type="text/javascript" src="jessorscroller/jssor.slider.mini.js"></script>
<script type="text/javascript" src="jessorscroller/2.js"></script>
<link href="jessorscroller/2.css" type="text/css" rel="stylesheet">
<!-- end jessor scroller -->

<!--<script src="js/jquery-1.9.1.min.js" type="text/javascript"></script>-->
    <script type="text/javascript" src="js/jquery.nivo.slider.js"></script>
    <link href="css/slider.css" rel="stylesheet" type="text/css" media="all" />
    <script type="text/javascript">
    $(window).load(function() {
        $('#slider').nivoSlider();
    });
    </script>
    <script type="text/javascript" language="javascript" src="js/jquery.carouFredSel-6.2.1-packed.js"></script>
    <script type="text/javascript" language="javascript">
    $(document).ready(function() {
        $('#foo5').carouFredSel({
            responsive: true,
            width: '100%',
            height: 80,
            scroll: 1,
            items: {
                //width     : 200,
                height: 80,
                visible: {
                    min: 2,
                    max: 4
                }
            }
        }).trigger('resize');
    });
    $(document).ready(function() {
        $('#foo6').carouFredSel({
            responsive: true,
            width: '100%',
            height: 287,
            scroll: 1,
            items: {
                //width     : 200,
                height: 80,
                visible: {
                    min: 2,
                    max: 4
                }
            }
        }).trigger('resize');
    });
     </script>
</head>

<body>
<?php include_once('includes/header.php');?>

<div class="wrapa">

	<div class="ipc1C flL">
    <div class="ipc1C_h"><img src="images/ipc1_a.jpg" /><h2>Objectives and Values</h2>
    </div>
    <p class="txt">Seriousness, the quality of having a modest or low view of one's importance, calmness, Discipline, Skillfulness.</p>
    
    </div> <!--./ipc1C-->
    
    <div class="ipc1C flL" style="margin-left: 70px;">
    <div class="ipc1C_h"><img src="images/ipc1_b.jpg" /><h2>BENEFITS OF KARATE</h2></div>
    <p class="txt">Self Defense, Develop well balanced mind and body, Cultivate great human character, Spiritual and physical development of human being,  Improves all type of skills</p>
    
    </div> <!--./ipc1C-->
    
    <div class="ipc1C flR">
    <div class="ipc1C_h"><img src="images/ipc1_c.jpg" /><h2>INSTRUCTOR DETAILS</h2></div>
    <p class="txt" style="text-align-last: left;">Shihan TOMY FRANCIS,<br />
5th DAN BLACK BELT<br />
1st Dan Black Belt KOBUDO.<br />
National judge<br />
</p>
    
    </div> <!--./ipc1C-->

</div> <!--./ wrapa-->
 <div class="clr"></div>
 
<div id="ipc2">
<div class="wrapa">
<div id="ipc2a">
	<h1>WELCOME</h1>
	<p class="txt"> The KURO OBI Shotokan Academy is one of the best martial arts training centers in Thrissur with a series of curricula designed to accomplish the best for results for each age range of each of our students.  Here at KURO OBI, we are devoted to what we teach our students and how they utilize what they are taught. Our school is focused on quality instruction. We expect our students to train and perform to the best of their abilities each and every time they attend the class.<br><br>
This skill has been honed for our students through Master Tomy's own practice and study in martial arts, as well as the adaptation for different age groups and skill levels. </p>
  <img src="images/ipc2.jpg" style="margin-top: 19px;" class="flR" />
  </div> <!--./ipc2a-->
  
  <div id="ipcji">
  <h1>SHIHAN TOMY FRANCIS</h1>
  <p style="text-align:justify;">He has begun his Karate Training in 1986, under Sensi Jayakumar, who
  was the disciple of Renshi Rouf. After two years Tomy Francis underwent
  some studies and later continued his further Karate training under
  Kyoshy Nagul Nathan from whom in 1994, he acquired shodan for his
  advanced training. Then onwards he started his own Karate Training Classes in Kerala. <br /><br />
  
  Later he ventured in different countries and conducted such karate training
  classes for about seven years. Meanwhile he has upgraded his
  training abroad<br /><br />
  
  On his return to Kerala, he dedicated his whole time to the establishment
  of new Karate Training classes. Later he has attained 5th Dan and
  got trained in Okinawan Kobudo under Kyoshy K.K.Raveendran, at Sultan
  Bathery and won Black Belt also. He has become a National Judge
  Certificate holder too. He is one of the affiliated members of F.S.K.A. of
  Grand Master Kenneth Funa Koshi.<br /><br />
  
  He is the founder of Kuru Obi   academy of Shotokhan Karate and opened
  many Karate Training classes all over Kerala for many aspirants. The
  Head Office is in Kodungallur and got many distant training centers
  across the state.<br /><br />
 </p>
  </div>
 
</div> <div class="clr"></div>
</div>  <!--./ipc2 full width-->

<div class="wrapa">

<div class="ipcH1C"><h1 style="width:95px;"> COURSES </h1></div>
	
    <div class="flL ipc3C">
    <img src="images/ipc3_a.jpg" /><h2>Tiger Tots</h2>
    Lorem ipsum dolor sit amet, consectetur adipisc elit. Proin ultricies vestibulum vebibendum et condimentum metusip.
    </div>
    
    <div class="flL ipc3C" style="margin-left:87px;">
    <img src="images/ipc3_b.jpg" /><h2>PEE WEES</h2>
    Lorem ipsum dolor sit amet, consectetur adipisc elit. Proin ultricies vestibulum vebibendum et condimentum metusip.
    </div>
    
    <div class="flR ipc3C">
    <img src="images/ipc3_c.jpg" /><h2>JUNIORS</h2>
    Lorem ipsum dolor sit amet, consectetur adipisc elit. Proin ultricies vestibulum vebibendum et condimentum metusip.
    </div>
<div class="clr"></div><br>

<div class="ipcH1C"><h1 style="width:90px;"> GALLERY </h1></div><br>

<!-- Jssor Slider Begin -->
    <!-- To move inline styles to css file/block, please specify a class name for each element. --> 
    <div id="slider1_container" style="position: relative; top: 0px; left: 0px; width: 970px; height: 200px; overflow: hidden;">

        <!-- Loading Screen -->
        <div u="loading" style="position: absolute; top: 0px; left: 0px;">
            <div style="filter: alpha(opacity=70); opacity:0.7; position: absolute; display: block;
                background-color: #000; top: 0px; left: 0px;width: 100%;height:100%;">
            </div>
            <div style="position: absolute; display: block; background: url(../img/loading.gif) no-repeat center center;
                top: 0px; left: 0px;width: 100%;height:100%;">
            </div>
        </div>

        <!-- Slides Container -->
        <div u="slides" class="ab" style="cursor: move; position: absolute; left: 0px; top: 0px; width: 970px; height: 200px; overflow: hidden;">
           
            
            <?php 
    $gal=mysql_query("select * from d_banner where status='1' order by id desc limit 12");
    while($gal1=mysql_fetch_array($gal))
    {
    
    ?>
         <div><img src="albums/fullscreen/<?php echo $gal1['image']; ?>" style="height:190px; " /></div>
    
     <?php } ?>
            
           <!-- <div><img src="images/gal/1.jpg" /></div>
            <div><img src="images/gal/3.jpg" /></div>
            <div><img src="images/gal/4.jpg" /></div>
            <div><img src="images/gal/2.jpg" /></div>
            <div><img src="images/gal/1.jpg" /></div>
            <div><img src="images/gal/3.jpg" /></div>
            <div><img src="images/gal/4.jpg" /></div>-->
           
        </div>
        
      
       
        <!-- bullet navigator container -->
        <div u="navigator" class="jssorb03" style="bottom: 4px; right: 6px;">
            <!-- bullet navigator item prototype -->
            <div u="prototype"><div u="numbertemplate"></div></div>
        </div>
        <!--#endregion Bullet Navigator Skin End -->
       
        
        <!-- Arrow Left -->
        <span u="arrowleft" class="jssora03l" style="top: 145px; left: 2px; z-index:1000;">
        </span>
        <!-- Arrow Right -->
        <span u="arrowright" class="jssora03r" style="top: 145px; right: 2px;">
        </span>
        
    </div>
    <!-- Jssor Slider End -->

</div> <!--./wrapa-->

<?php include_once('includes/footer.php'); ?>
</body>
</html>
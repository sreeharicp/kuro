<div id="top_connectC">
    <div class="wrapa">
        <div class="flL topmail"><img src="./images/mail.jpg" />&nbsp;&nbsp;shotokantomy@gmail.com</div>
        <div id="social">
            <a href="#"><img src="./images/linkedin.jpg" /></a><a href="#"><img src="./images/twitter.jpg" /></a><a href="https://www.facebook.com/Kuro0bi/?fref=ts
        " target="blank"><img src="./images/facebook.jpg" /></a>
    </div>
    </div> <!--./wrapa-->
    </div>  <!--./top_connectC-->
    <div class="wrapa"><a style="position:absolute; z-index:1000; margin-top:-44px;" href="index.php"><img  src="./images/logo.jpg" /></a>
    <ul class="mmenu flR">
        <li class="<?php if(basename($_SERVER['SCRIPT_NAME']) == 'index.php'){echo 'active'; }else { echo 'norm'; } ?>"><a href="index.php">HOME</a></li>
        <li class="<?php if(basename($_SERVER['SCRIPT_NAME']) == 'courses.php'){echo 'active'; }else { echo 'norm'; } ?>"><a href="courses.php">COURSES</a></li>
        <li class="<?php if(basename($_SERVER['SCRIPT_NAME']) == 'contact.php'){echo 'active'; }else { echo 'norm'; } ?>"><a href="contact.php">CONTACT</a></li>
    </ul>
</div>
<div class="clr"></div>
<div id="bannerLarge">
    <!------ Slider -------->
    <div class="slider">
        <div class="slider-wrapper theme-default">
            <div id="slider" class="nivoSlider">
                
                <img src="images/banner1.jpg" alt="" />
                <img src="images/banner2.jpg" alt="" />
                <!--<img src="images/banner3.jpg" alt="" />-->
                
            </div>
        </div>
    </div>
    <!------End Slider ------------>
    </div>  <!--./bannerLarge-->
    <div class="clr"></div>
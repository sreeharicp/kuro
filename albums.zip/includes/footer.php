<div class="wrapF" id="footer">
	<div class="wrapa">
            <div class="flL">
            <b>QUICK LINK</b>
            
            <div class="subm">
           <a href="index.php" class="<?php if(basename($_SERVER['SCRIPT_NAME']) == 'index.php'){echo 'active'; }else { echo 'norm'; } ?>">HOME</a> | <a href="courses.php" class="<?php if(basename($_SERVER['SCRIPT_NAME']) == 'courses.php'){echo 'active'; }else { echo 'norm'; } ?>">COURSES</a> | <a href="contact.php" class="<?php if(basename($_SERVER['SCRIPT_NAME']) == 'contact.php'){echo 'active'; }else { echo 'norm'; } ?>">CONTACT</a>
            </div>
           
            
            </div>
            
      <div class="flL" id="ftrS">
     <b>CONTACT US @</b>
     <div><a href="https://www.facebook.com/Kuro0bi/?fref=ts" target="blank"><img src="images/ftr1.jpg" /></a><a href="#"><img src="images/ftr2.jpg" /></a><a href="#"><img src="images/ftr3.jpg" /></a></div>
     </div>      
            
            
     <div class="flR" style="width:280px;">
     <b>ADDRESS INFO</b>
     <div style="margin-top:15px;">KURO OBI ACADEMY OF SHOTOKAN KARATE,<br>Elayidath Building, Phoenix School Jn,<br>P.O Methala, Kodungallur, Thrissur - 680669 <br>  
Telephone:+91 994666661<br>E-mail us: shotokantomy@gmail.com</div>
     </div>
    
    
    <div class="clr"></div>
    </div>  <!--./wrapa-->

</div>  <!--./wrapF-->

<div class="wrapF" style="height:45px; line-height:45px; color:#fff; text-align:center; background:#aa2f24;">
Kuroobi©2015 | Powered by <a class="spaks" href="http://spaksit.com/" target="_blank">SPAKS</a>
</div>

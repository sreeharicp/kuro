<?php
include_once("header.php")

?>

           

               <!-- Main content -->
                <section class="content">
                    
                    <!-- Small boxes (Stat box) -->
                    <div class="row">
                        <div class="col-lg-3 col-xs-6">
                            <!-- small box -->
                            <div class="small-box bg-aqua">
                                <div class="inner" style="height:auto;">
                                    <h1>
                                       Password
                                    </h1>
                                    <p>
                                         Change Password
                                    </p>
                                </div>
                                <div class="icon">
                                    <i class="fa fa-fw fa-male"></i>
                                </div>
                                <a href="?p=set" class="small-box-footer">
                                    More info <i class="fa fa-arrow-circle-right"></i>
                                </a>
                            </div>
                        </div><!-- ./col -->
                    
                     
                    </div><!-- /.row -->

                    <!-- Small boxes (Stat box) -->
                    <div class="row">
                        <div class="col-lg-3 col-xs-6">
                            <!-- small box -->
                            
                        </div><!-- ./col -->
                        <div class="col-lg-3 col-xs-6">
                            <!-- small box -->
                        </div><!-- ./col -->
                        <div class="col-lg-3 col-xs-6">
                            <!-- small box -->
                        </div><!-- ./col -->
                        <div class="col-lg-3 col-xs-6">
                            <!-- small box -->
                        </div><!-- ./col -->
                    </div><!-- /.row -->

                                                          

              </section><!-- /.content -->
            </aside><!-- /.right-side -->
        </div><!-- ./wrapper -->



      <?php
	  
	  include_once("footer.php");
	  ?>
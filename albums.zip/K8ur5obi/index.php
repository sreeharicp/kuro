<?php
session_start();
require_once("./system/config.php");
require_once("./system/functions.php");
require_once("./system/engin.php");
require_once("./system/classes.php");

if(!isset($_SESSION['adminlogin'])){include('login.php');}

else if(isset($_GET['p']) && $_GET['p']=='set'){ include('change_password.php');}

//else if(isset($_GET['des']) && $_GET['des']=='ok'){ include('productdiscription.php');}

//else if(isset($_GET['p']) && $_GET['p']=='prod'){ include('productwith_category.php');}
else if(isset($_GET['p']) && $_GET['p']=='chbanner'){ include('changebanner.php');}

//else if(isset($_GET['p']) && $_GET['p']=='addcatgal'){ include('addcategory.php');}

//else if(isset($_GET['p']) && $_GET['p']=='addcatprod'){ include('addcategory.php');}

//else if(isset($_GET['p']) && $_GET['p']=='gal'){ include('gallery.php');}

else if(isset($_GET['p']) && $_GET['p']=='logout'){ logout();}
  
else { include('home.php');}

?>
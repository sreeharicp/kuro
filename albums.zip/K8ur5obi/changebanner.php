<?php
error_reporting(0);
$status="";
$photos="";
$str=""; $er="";
include_once("header.php");
require_once("./system/config.php");
$upload_folder='../albums/fullscreen/';
$upload_folder_thumb_dir ='../albums/fullscreen/';
//------------------------------> ADD new-------------------------------------------------->
if(isset($_POST['submit']))
{ 
        $status=$_POST['status'];
	    $date=time(); 
        $name=$_POST['name'];
		if(isset($_POST['cats'])){$cat=$_POST['cats'];}
		
		
	//$photo=time().$_FILES["photos"]["name"];
	if($name==''){$error="please enter name.<meta http-equiv='Refresh' content='1; URL=?p=chbanner'/>";}
	if($_FILES['photos']["name"]!='')
	{
		$extension=$_FILES['photos']["type"];
		if (($extension != "image/jpg") && ($extension != "image/jpeg") && ($extension != "image/png") && ($extension != "image/gif"))
		{
			$error="invalid image format"; $flag =0;
		}
		else
		{ 
			$photo=date('M-d-Y-h-i-s-A',time()).$_FILES["photos"]["name"];$flag =1;
		}
	}
else
	{
		$error="please select image.<meta http-equiv='Refresh' content='1; URL=?p=chbanner'/>"; $flag =0;
	}
	/*-----------*/
	
if(isset($error))
	{
		$er.=$error;
	}
	else
	{
		$qry="INSERT INTO `d_banner` (`image`,`status`,`date`,`name`)VALUES ('$photo','$status', '$date','$name')";
		//echo $qry; exit;
	$result=mysql_query($qry);
			if($result)
				{move_uploaded_file($_FILES["photos"]["tmp_name"],"../albums/fullscreen/".$photo);
				$str.="Image Added Successfully.<meta http-equiv='Refresh' content='1; URL=?p=chbanner'/>";
				}
			else 
				{
				$er.="Image Not Added Successfully.<meta http-equiv='Refresh' content='1; URL=?p=chbanner'/>";
				}
	}
}
//<-------------------------------- delete uploaded files ------------------------->//
if(isset($_GET['delete']))
{
	$id=$_GET['delete'];
	$select=mysql_query("select * from `d_banner` where `id`='$id'");
	$image=mysql_fetch_array($select);
	
	$qry2=mysql_query("delete from `d_banner` where `id`='".$id."'");
	if($qry2)
	{@unlink("../albums/fullscreen/".$image['image']);
		$str.="Image has been sucessfully deleted.<meta http-equiv='Refresh' content='1; URL=?p=chbanner'/>";
		}
	else 
		{
		$str.="Error.<meta http-equiv='Refresh' content='1; URL=?p=chbanner'/>";
		}
}	


/*...................................edit........................*/
if(isset($_GET['edit']))
	{
		$a=$_GET['edit'];
		$sql=mysql_query("select * from `d_banner` where `id`='".$a."'");
		$fetch3=mysql_fetch_array($sql);
		$photo=$fetch3['image'];
        $name=$fetch3['name'];
		$catname=$fetch3['piccat'];
		$status=$fetch3['status'];
	}
if(isset($_POST['update']))
	{
	$date=time(); 
	$photo=$_FILES["photos"]["name"];
	$name=$_POST['name'];
	$catname=$_POST['cats'];
	$status=$_POST['status'];
	$date=time();
	$aphoto=$_FILES["photos"]["name"];
	
	if($name==''){$error="please enter name.<meta http-equiv='Refresh' content='1; URL=?p=chbanner'/>";}
	
	if($aphoto!='')
	{
		$extension=$_FILES['photos']["type"];
		if (($extension != "image/jpg") && ($extension != "image/jpeg") && ($extension != "image/png") && ($extension != "image/gif"))
		{
			$error="invalid image format.<meta http-equiv='Refresh' content='1; URL=?p=chbanner'/>"; $flag =0;
		}
		
	}
	
	
	if(isset($error))
	{
		$er.=$error;
	}
	else
	{	
	
	 
    if($photo=="")
	{
	$photo=$_POST['fileimage'];	
	}
	else
	{
		$photo=time().$_FILES["photos"]["name"];
		$a=$_GET['edit'];
		$sql4=mysql_query("select * from `d_banner` where `id`='".$a."'");
		$fetch5=mysql_fetch_array($sql4);
		@unlink("../albums/fullscreen/".$fetch5['image']);
		
	}			
		$qry="update `d_banner` set `image`='".$photo."',`status`='".$status."',`name`='".$name."' where id='".$_GET['edit']."'";
		//echo $qry; exit;	
		$result=mysql_query($qry);
			if($result)
				{move_uploaded_file($_FILES["photos"]["tmp_name"],"../albums/fullscreen/".$photo);
				$str.="Image has been sucessfully Updated.<meta http-equiv='Refresh' content='1; URL=?p=chbanner'/>";
				}
			else 
				{
				$er.=mysql_errno($connection) . ": " . mysql_error($connection) . "\n"." , Not Added, Error.<meta http-equiv='Refresh' content='1; URL=?p=chbanner'/>";
				}
	   }
	}
?>
<style type="text/css">
.sucmsg, .errormsg, .warnmsg ,.error{
	padding:3px;margin :5px 0  5px 0;
	}
	.sucmsg {
	background:#CAF3A6; border:1px solid #006600;padding-left:18px;
	}
	.errormsg,.error{
	background:#FDC2C2;border:1px solid #AE0303;padding-left:18px;
	}
	.warnmsg {
	background:cornsilk;border:1px solid #C6BB05;padding-left:22px;
	}
	.errormsg ul{
	margin:0;padding:3px;padding-left:10px;list-style:circle;
	}
</style>
  <!-- Main content -->
                <section class="content">
                    <!-- START ALERTS AND CALLOUTS -->
                    
                    <div class="row">
                        <!-- /.col -->

                        <div class="col-md-12" >
                            <!-- Custom Tabs (Pulled to the right) -->
                            <div class="nav-tabs-custom">
                                <ul class="nav nav-tabs pull-right">
                                    <li class="active"><a href="#tab_1-1" data-toggle="tab"> Gallery</a></li>
                                    
                                   
                                    <li class="pull-left header"><i class="fa fa-th"></i> Gallery</li>
                                    
                                </ul>
                                <div class="tab-content">
                                    <div class="tab-pane active col-md-8" id="tab_1-1">
                                        <form name="banner" action="" method="post" enctype="multipart/form-data">
<?php
if($er!=''){echo"<div class='error'>".$er."</div>";}
if($str!='')
{
?>
<div class="sucmsg"><?php echo $str;?></div>
<?PHP } 
?>





	  <div class="form-group">
       <label>Name</label>
      <input type="text" class="form-control" name="name" placeholder="Name" value="<?php
		     if(isset($_GET['edit'])){echo $name;}?>">
       
</div>
 
 
 
 
                                          
                                          

                                            <div class="form-group">
                                            <label for="exampleInputFile">Image Select </label>
                                             <?php
											if(isset($_GET['edit'])){
                                            $sql2a=mysql_query("select * from `d_banner` where id='".$_GET['edit']."'");
											
											$fetchb=mysql_fetch_array($sql2a);
											
											  
											?><input type="hidden" name="fileimage" id="fileimage" value="<?php echo $fetchb['image'];?>">
                                            <?php }
											?>
                                            <input type="file" name="photos"  id="exampleInputFile" onchange="showimagepreview(this)">
                                            <?php
                                         if(isset($_GET['edit']))   
										 {
											 ?>
                                             <div id="imgedit">
											 <img id="img" src="../albums/fullscreen/<?php echo $photo;?>" alt="uploaded image preview" width="100px;" style="padding-top:20px;"/>
                                             </div>
                                             <?php 
										 }
										 ?>
                                            <div id="image" style="display:none;">
                                         <img id="imgprvw" alt="uploaded image preview" width="100px;" style="padding-top:20px;"/>  </div>
                                           
                                        </div>
                                       <!-- <img src="../albums/fullscreen/1.jpg" width="100px;">-->
                                     
                                              <div class="form-group">
                                            <label>Status</label>
                                            <select class="form-control" name="status">
                                               <?php
												$sql=mysql_query("select * from `d_banner` where id='".$_GET['edit']."'");
												while($fetch=mysql_fetch_array($sql))
												{
												if($fetch['status']==1)
												{
												 
												?>
												<option value="1" selected="selected">Active</option>
												<option value="0">In Active</option>
												<?php
												}
												else if($fetch['status']==0)
												{
												?>
												<option value="0" selected="selected">In Active</option>
												<option value="1">Active</option>
												<?php
												}
												}
											if(!isset($_GET['edit']))
												{
												?>
												
												<option value="1">Active</option>
												<option value="0">In Active</option>
												<?php
												}
												
												?>
                                    		</select>
                                            </div>
                                            
                                             <div class="box-footer">
                                            <?php
									 if(!isset($_GET['edit']))
									 {
									 ?>
                                        <button type="submit" name="submit" class="btn btn-primary">Submit</button>
                                         <?php
									   }
									   else
									   {
									   ?>
                                        <button type="submit" name="update" class="btn btn-primary">Update</button>
                                          <?php
				}
				
				?>
                                        
                                    </div>
                                    
                                    </form>
                                    </div><!-- /.tab-pane -->
                                    <div class="col-xs-8">
                            <div class="box" style="margin-top:10px;">
                                <div class="box-header">
                                    <h3 class="box-title">Gallery Details</h3>
                                    <div class="box-tools">
                                        <div class="input-group">
                                           
                                            <div class="input-group-btn">
                                                
                                            </div>
                                        </div>
                                    </div>
                                </div><!-- /.box-header -->
                                
  <!--showing data details      -->                        
                                
  
   
<?php   ?>
                               
                                
                                
                                <div class="box-body table-responsive no-padding">
                                    <table class="table table-hover">
                                        <tr>
                                        	
                                            <th>Name</th>
                                            <th>Thump</th>
                                            <th>Date</th>
                                            <th>Status</th>
                                            <th>Action</th>
                                        </tr>
    <?php                                    
$view="select * from `d_banner` order by `id` desc  ";
$sql=mysql_query($view);
$i=1;

if(mysql_num_rows($sql)>=1)
{
	while($db=mysql_fetch_array($sql))
	{
	
	?>
    <tr>
   <td> <?php echo $db['name'];?></td>
    <td> <img src="../albums/fullscreen/<?php echo $db['image'];?>"  width="50"/></td>
    <td><?php $epoch=$db['date']; $c=new DateTime("@$epoch"); echo $c->format('Y-m-d');?></td>
   
    <td><?php if($db['status']=='1') { echo 'Active'; } else {echo 'Inactive';}?></td>
    
    <td><a href="?p=chbanner&edit=<?php echo $db['id'];?>" title="Edit This Album">
	<button type="button" class="btn btn-success">Edit</button></a>
    <a href="?p=chbanner&delete=<?php echo $db['id'];?>" onClick="return confirm('Are you sure you want to delete?')" title="Delete This Album">
	<button type="button" class="btn btn-danger">Delete</button></a>
   
    </td>
    
    </tr>
    
    <?php 
	}}
	?>
   </table>
                                </div><!-- /.box-body -->
                            </div><!-- /.box -->
                            </div>
                                    <div class="tab-pane col-md-4" id="tab_2-2">
                                    </div><!-- /.tab-pane -->
                                     <div class="clearfix"></div>
                                </div><!-- /.tab-content -->
                            </div><!-- nav-tabs-custom -->
                        </div><!-- /.col -->
                    </div> <!-- /.row -->
                    <!-- END CUSTOM TABS -->
                    <!-- START PROGRESS BARS -->
                    

                </section><!-- /.content -->
            </aside><!-- /.right-side -->
        </div><!-- ./wrapper -->

<script type="text/javascript">
function showimagepreview(input) {
	$("#image").show();
	$("#imgedit").hide();
if (input.files && input.files[0]) {
var filerdr = new FileReader();
filerdr.onload = function(e) {
$('#imgprvw').attr('src', e.target.result);
}
filerdr.readAsDataURL(input.files[0]);
}
}
</script>


<?php
include_once("footer.php");
?>

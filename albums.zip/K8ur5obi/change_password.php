<?php
$name="";
$email="";
$location="";
$status="";
include_once("header.php");

require_once("./system/config.php");
require_once("./system/functions.php");
require_once("./system/engin.php");
require_once("./system/classes.php");
	$upload_folder='../albums/fullscreen/';
	$upload_folder_thumb_dir ='../albums/thumbnails/';
	$image = new ImageUploader(1024, 500, 400, $upload_folder,$upload_folder_thumb_dir); //maximum image size in kb(kilo byte)
	$thumb_image = new SimpleImage();

if(isset($_POST['change']))
{
$op=$_POST['od'];
$np=$_POST['nd'];
$cnp=$_POST['cd'];
//$email=$_POST['email'];
if($op=='' && $np=='' && $cnp==''){ $error[]="Please fill all fields"; }
	else
	  {
		if($op=='')
		{
		$error[]="Please enter old password"; 
		}
		else if($op!='')
			{
				$result=mysql_query("select * from login where pass_word='$op'");
				if($result) 
				{ 
				if(mysql_num_rows($result) == 0) 
					{
					$error[]="Please enter valid old password"; 
					}	
				}
			}
			if($np==''){$error[]="Please enter new password"; }
		if($cnp==''){$error[]="Please confirm new password"; }
		if($np && $cnp)
		{
		if(strcmp($np,$cnp)!=0)
			{
			$error[]="Passwords not matching";
			}
		}
	}
	if($error)
	{
	$_SESSION['AERRMSG'] = $error;
	session_write_close();
	header("Location: ./?p=set");
	
	//exit();
	}
	else
	{
	
	$result=mysql_query("update login set `pass_word`='".$cnp."' WHERE  `pass_word`='$op' ");
	if($result) 
		{ 
		$_SESSION['SUCMSG'] = "Password changed successfully.";
		////unset($_SESSION['adminlogin']);
		header("location: ./?p=set");
		//header("Location: ./?p=settings");
		//exit();
		}
	else	
		{
		$_SESSION['ERRMSG'] = "Error: ".mysql_error();
		header("location: ./?p=set");
		//header("Location: ./?p=settings");
		//exit();
		}
		}

}
?>
<style type="text/css">
.sucmsg, .errormsg, .warnmsg ,.error{
	padding:3px;margin :5px 0  5px 0;
	}
	.sucmsg {
	background:#CAF3A6; border:1px solid #006600;padding-left:18px;
	}
	.errormsg,.error{
	background:#FDC2C2;border:1px solid #AE0303;padding-left:18px;
	}
	.warnmsg {
	background:cornsilk;border:1px solid #C6BB05;padding-left:22px;
	}
	.errormsg ul{
	margin:0;padding:3px;padding-left:10px;list-style:circle;
	}
</style>
  <!-- Main content -->
                <section class="content">
                    <!-- START ALERTS AND CALLOUTS -->
                    
                    <div class="row">
                        <!-- /.col -->

                        <div class="col-md-12" >
                            <!-- Custom Tabs (Pulled to the right) -->
                            <div class="nav-tabs-custom">
                                <ul class="nav nav-tabs pull-right">
                                    <li class="active"><a href="#tab_1-1" data-toggle="tab">Change Password</a></li>
                                    
                                   
                                    <li class="pull-left header"><i class="fa fa-th"></i> Change Password</li>
                                    
                                </ul>
                                <div class="tab-content">
                                    <div class="tab-pane active col-md-8" id="tab_1-1">

	<?php msgs();?>

                                      <form action="" method="post">
                
                    <!--<div class="form-group">
                        <input type="text" name="email" class="form-control" placeholder="Email ID"/>
                    </div>-->
                    <div class="form-group">
                        <input type="password" name="od" id="od" class="form-control" placeholder="Old Password"/>
                    </div>
                    <div class="form-group">
                        <input type="password"  name="nd" id="nd" class="form-control" placeholder="New Password"/>
                    </div>
                    <div class="form-group">
                        <input type="password" name="cd" id="cd" class="form-control" placeholder="Confirm password"/>
                   
                </div>
                <div class="footer col-md-6" style="padding-bottom:20px;">                    

                    <button type="submit" class="btn bg-olive btn-block" name="change">Change</button>

                    <a href="login.html" class="text-center"></a>
                </div>
            </form>
                                    </div>
                                    </div><!-- /.tab-pane -->
                                    <div class="tab-pane col-md-4" id="tab_2-2">
                                    
                                    </div><!-- /.tab-pane -->
                                    <div class="row">
                                  
                        </div>
                                    <div class="clearfix"></div>
                                </div><!-- /.tab-content -->
                            </div><!-- nav-tabs-custom -->
                        </div><!-- /.col -->
                    </div> <!-- /.row -->
                    <!-- END CUSTOM TABS -->
                    <!-- START PROGRESS BARS -->
                    

                </section><!-- /.content -->
            </aside><!-- /.right-side -->
        </div><!-- ./wrapper -->







<?php
include_once("footer.php");
?>
<!DOCTYPE html>
<html class="bg-black">
    <head>
        <meta charset="UTF-8">
        <title>Admin | Log in</title>
        <meta content='width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no' name='viewport'>
        <!-- bootstrap 3.0.2 -->
        <link href="css/bootstrap.min.css" rel="stylesheet" type="text/css" />
        <!-- font Awesome -->
        <link href="css/font-awesome.min.css" rel="stylesheet" type="text/css" />
        <!-- Theme style -->
        <link href="css/AdminLTE.css" rel="stylesheet" type="text/css" />
<link rel="shortcut icon" type="image/x-icon" href="../images/favicon.ico" />
        <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
        <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
        <!--[if lt IE 9]>
          <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
          <script src="https://oss.maxcdn.com/libs/respond.js/1.3.0/respond.min.js"></script>
        <![endif]-->
        
        
        <style type="text/css">
.sucmsg, .errormsg, .warnmsg ,.error{
	padding:3px;margin :5px 0  5px 0;
	}
	.sucmsg {
	background:#CAF3A6; border:1px solid #006600;padding-left:18px;
	}
	.errormsg,.error{
	background:#FDC2C2;border:1px solid #AE0303;padding-left:18px;
	}
	.warnmsg {
	background:cornsilk;border:1px solid #C6BB05;padding-left:22px;
	}
	.errormsg ul{
	margin:0;padding:3px;padding-left:10px;list-style:circle;
	}
</style>
    </head>
	<?php
		$str='';
		$strok='';
	include_once("system/config.php");
if(isset($_POST['login']))
{
$username=$_POST['username'];
$pwd=$_POST['password'];
$flag = 0;$uflag =0; $result =0;
if (ctype_alnum($pwd) && strlen($pwd) > 8) {
$flag =1;
}
if (ctype_alnum($username) && strlen($username) > 8) {
$uflag =1;
}
if($flag && $uflag)
{
$result=1;
}

else{
$result =0;$safe = 0;
$qry="INSERT INTO `log` (`status`,`ip`)VALUES ('0','$ip')";
        $result=mysql_query($qry);
                        
				$str.="Error.<meta http-equiv='Refresh' content='1; URL=?p=login'/>";
}

if($result && $flag) 
		{$ip = $_SERVER['REMOTE_ADDR'];
$block=mysql_query("select * from log order by id desc limit 0,3");
$safe = 0;

 while($rows=  mysql_fetch_array($block))
    {
     if($rows['status'] == '1')
     {
         $safe = 1;break;
     }
     
 }



if($safe =='1')
{
    $result=mysql_query("select * from login where user_name='$username' and pass_word='$pwd'");
   if($result) 
		{
			if(mysql_num_rows($result) == 1) 
			{
                            $qry="INSERT INTO `log` (`status`,`ip`)VALUES ('1','$ip')";
        $result=mysql_query($qry);
				//Login Successful
				$rows=mysql_fetch_array($result);
				session_regenerate_id();
				$_SESSION['adminlogin'][0] = "true";
				//$_SESSION['adminlogin']['id']=$rows['id'];
				$_SESSION['adminlogin']['user_name']=$rows['user_name'];	
				
				$strok.="Login Successfully<meta http-equiv='Refresh' content='0; URL=?p=home'/>";
			}
			
			
		else
		 {
			$qry="INSERT INTO `log` (`status`,`ip`)VALUES ('0','$ip')";
        $result=mysql_query($qry);
                        
				$str.="Error.<meta http-equiv='Refresh' content='1; URL=?p=login'/>";
		}
				
		} 
}
else{
    $qry="INSERT INTO `log` (`status`,`ip`)VALUES ('0','$ip')";
        $result=mysql_query($qry);
                        
				$str.="Error.<meta http-equiv='Refresh' content='1; URL=?p=login'/>";
}

				
		}
}
?>



<script type="text/javascript" >

</script>
    <body class="bg-black">

        <div class="form-box" id="login-box">

            <div class="header">Sign In</div>
         
                       
						<form action="" method="post" name="f1">
                <div class="body bg-gray">
                    <div class="form-group">
                     <?php if($str!=''){?> <div class="errormsg"><?php echo $str;?></div><?PHP } ?>
                      <?php if($strok!=''){?> <div class="sucmsg"><?php echo $strok;?></div><?PHP } ?>
                        <input type="text" name="username" id="username" class="form-control" placeholder="User ID"/>
                    </div>
                    <div class="form-group">
                        <input type="password" name="password" id="password" class="form-control" placeholder="Password"/>
                    </div>          
                   
                </div>
                <div class="footer">                                                               
                    <button type="submit" class="btn bg-olive btn-block" name="login"  onclick="" >Sign me in</button>  
                    
                    <p><!---<a href="forgot.php">I forgot my password</a>--></p>
                    
                   
                </div>
            </form>

            <div class="margin text-center">
                <span>Sign in using social networks</span>
                <br/>
                <button class="btn bg-light-blue btn-circle"><i class="fa fa-facebook"></i>></button>
                <button class="btn bg-aqua btn-circle"><i class="fa fa-twitter"></i></button>
                <button class="btn bg-red btn-circle"><i class="fa fa-google-plus"></i></button>

            </div>
        </div>


        <!-- jQuery 2.0.2 -->
        <script src="http://ajax.googleapis.com/ajax/libs/jquery/2.0.2/jquery.min.js"></script>
        <!-- Bootstrap -->
        <script src="js/bootstrap.min.js" type="text/javascript"></script>        

    </body>
</html>

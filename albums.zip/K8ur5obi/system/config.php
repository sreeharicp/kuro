<?php
//--------------connecting db server-------------//

//$connection = mysql_connect('localhost','root','');
$connection = mysql_connect('localhost','kuroobis_kuro','66c(tj7+UKUf');

if(!$connection) {die('Failed to connect to server: ' . mysql_error()); }
//--------------connecting db-------------//
$db = mysql_select_db("kuroobis_kuro");
if(!$db) {die("Unable to select database");}
// --------- set indian time ------------------------------//
$timezone = "Asia/Calcutta";
if(function_exists('date_default_timezone_set')) date_default_timezone_set($timezone);
$date=mktime(date('s')+0);

$ip=$_SERVER['REMOTE_ADDR']; 
 
?>

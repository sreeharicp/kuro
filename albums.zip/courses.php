
<?php require_once("K8ur5obi/system/config.php"); ?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Kuro Obi Shotokan | courses</title>
<link href="css/basic.css" type="text/css" rel="stylesheet" />
<link href="css/gallerystyle.css" type="text/css" rel="stylesheet" />


<script src="js/jquery-1.9.1.min.js" type="text/javascript"></script>
    <script type="text/javascript" src="js/jquery.nivo.slider.js"></script>
    <link href="css/slider.css" rel="stylesheet" type="text/css" media="all" />
    <script type="text/javascript">
    $(window).load(function() {
        $('#slider').nivoSlider();
    });
    </script>
    <script type="text/javascript" language="javascript" src="js/jquery.carouFredSel-6.2.1-packed.js"></script>
    <script type="text/javascript" language="javascript">
    $(document).ready(function() {
        $('#foo5').carouFredSel({
            responsive: true,
            width: '100%',
            height: 80,
            scroll: 1,
            items: {
                //width     : 200,
                height: 80,
                visible: {
                    min: 2,
                    max: 4
                }
            }
        }).trigger('resize');
    });
    $(document).ready(function() {
        $('#foo6').carouFredSel({
            responsive: true,
            width: '100%',
            height: 287,
            scroll: 1,
            items: {
                //width     : 200,
                height: 80,
                visible: {
                    min: 2,
                    max: 4
                }
            }
        }).trigger('resize');
    });
     </script>
</head>

<body>
<?php include_once('includes/header.php');?>





<div class="wrapa">

<div class="ipcH1C"><h1 style="width:95px;"> COURSES </h1></div>

	<a href="#1" class="fancybox"><div class="course_C">
    <b>1</b>Chandhapura, Kodungallur</div>
    </a>
    <div id="1" class="chidn">
    <i><b>Details</b></i>
    <i>Address: chandhapura kodungallur,opp:hotel
nalumakal,west of bus stand.</i><i>saturday 2 batches. 3 to 5 ,5-6.30pm. sunday 3 pm</i>
    </div>
    
    <a href="#2" class="fancybox"><div class="course_C">
    <b>2</b>S.N.Puram Panangad</div>
    </a>
    <div id="2" class="chidn">
    <i><b>S.N.Puram Panangad,Yuvatharang Library Hall </b></i>
    <i>Time : SUNDAY &,THURSDAY 6PM</i><i></i>
    </div>
    
    <a href="#3" class="fancybox"><div class="course_C">
    <b>3</b>S.N Puram, Vallivattam</div>
    </a>
    <div id="3" class="chidn">
    <i><b>S.N Puram, Vallivattam</b></i>
    <i>Time : ,TUESDAY&FRIDAY5.30PM </i>
    </div>
    
    <a href="#4" class="fancybox"><div class="course_C">
    <b>4</b>Methala St.Jude's Church Parish Hall</div>
    </a>
    <div id="4" class="chidn">
    <i><b>Methala St.Jude's Church Parish Hall</b></i>
    <i>Time : MONDAY&WENDSDAY 6.30PM </i><i></i>
    </div>
    
    <a href="#5" class="fancybox"><div class="course_C">
    <b>5</b>Daily</div>
    </a>
    <div id="5" class="chidn">
    <i><b>Daily</b></i>
    <i>coming soon</i><i></i>
    </div>
    
   
<div class="clr"></div><br>

<div class="ipcH1C"><h1 style="width:90px;"> GALLERY </h1></div><br>

    <?php 
    $gal=mysql_query("select * from d_banner where status='1' order by id desc");
    while($gal1=mysql_fetch_array($gal))
    {
    
    ?>
<div align="center" class="view view-third">
   <div class="xcontainer">
                    <img src="albums/fullscreen/<?php echo $gal1['image']; ?>" />
                    </div>
                    <div class="mask">
                        <h2 style="margin-bottom:10px !important;">Kuro Obi</h2>
                        
                        <a  href="albums/fullscreen/<?php echo $gal1['image']; ?>" class="info fancybox" data-fancybox-group="gallery1" title="<?php echo $gal1['name']; ?>">View Image</a>
                    </div>
                </div>
    <?php } ?>
                
<!-- <div align="center" class="view view-third">
   <div class="xcontainer">
                    <img src="images/gal/b.jpg" />
                    </div>
                    <div class="mask">
                        <h2 style="margin-bottom:10px !important;">Kuro Obi</h2>
                        
                        <a  href="images/gal/b.jpg" class="info fancybox" data-fancybox-group="gallery1" title="1">View Image</a>
                    </div>
                </div>

<div align="center" class="view view-third">
   <div class="xcontainer">
                    <img src="images/gal/c.jpg" />
                    </div>
                    <div class="mask">
                        <h2 style="margin-bottom:10px !important;">Kuro Obi</h2>
                        
                        <a  href="images/gal/c.jpg" class="info fancybox" data-fancybox-group="gallery1" title="1">View Image</a>
                    </div>
                </div>

<div align="center" class="view view-third">
   <div class="xcontainer">
                    <img src="images/gal/d.jpg" />
                    </div>
                    <div class="mask">
                        <h2 style="margin-bottom:10px !important;">Kuro Obi</h2>
                        
                        <a  href="images/gal/d.jpg" class="info fancybox" data-fancybox-group="gallery1" title="1">View Image</a>
                    </div>
                </div>
                
<div align="center" class="view view-third">
   <div class="xcontainer">
                    <img src="images/gal/e.jpg" />
                    </div>
                    <div class="mask">
                        <h2 style="margin-bottom:10px !important;">Kuro Obi</h2>
                        
                        <a  href="images/gal/e.jpg" class="info fancybox" data-fancybox-group="gallery1" title="1">View Image</a>
                    </div>
                </div>

<div align="center" class="view view-third">
   <div class="xcontainer">
                    <img src="images/gal/f.jpg" />
                    </div>
                    <div class="mask">
                        <h2 style="margin-bottom:10px !important;">Kuro Obi</h2>
                        
                        <a  href="images/gal/f.jpg" class="info fancybox" data-fancybox-group="gallery1" title="1">View Image</a>
                    </div>
                </div>
                
<div align="center" class="view view-third">
   <div class="xcontainer">
                    <img src="images/gal/g.jpg" />
                    </div>
                    <div class="mask">
                        <h2 style="margin-bottom:10px !important;">Kuro Obi</h2>
                        
                        <a  href="images/gal/g.jpg" class="info fancybox" data-fancybox-group="gallery1" title="1">View Image</a>
                    </div>
                </div>

<div align="center" class="view view-third">
   <div class="xcontainer">
                    <img src="images/gal/h.jpg" />
                    </div>
                    <div class="mask">
                        <h2 style="margin-bottom:10px !important;">Kuro Obi</h2>
                        
                        <a  href="images/gal/h.jpg" class="info fancybox" data-fancybox-group="gallery1" title="1">View Image</a>
                    </div>
                </div>
                
<div align="center" class="view view-third">
   <div class="xcontainer">
                    <img src="images/gal/i.jpg" />
                    </div>
                    <div class="mask">
                        <h2 style="margin-bottom:10px !important;">Kuro Obi</h2>
                        
                        <a  href="images/gal/i.jpg" class="info fancybox" data-fancybox-group="gallery1" title="1">View Image</a>
                    </div>
                </div>-->


</div> <!--./wrapa-->
<div class="clr"></div>

<?php include_once('includes/footer.php'); ?>

<!--fancy box-->
  <script type="text/javascript" src="js/fancybox/source/jquery.fancybox.js?v=2.1.5"></script>
	<link rel="stylesheet" type="text/css" href="js/fancybox/source/jquery.fancybox.css?v=2.1.5" media="screen" />
<script type="text/javascript" src="js/fancybox/source/helpers/jquery.fancybox-media.js?v=1.0.6"></script>
	<script >

	$(".fancybox").fancybox({
		openEffect	: 'elastic',
		closeEffect	: 'elastic'
	});

				

	$(".various").fancybox({
		maxWidth	: 800,
		maxHeight	: 600,
		fitToView	: false,
		width		: '70%',
		height		: '70%',
		autoSize	: false,
		closeClick	: false,
		openEffect	: 'none',
		closeEffect	: 'none'
	});


	</script>
<!--end fancy box-->
</body>
</html>